#ifndef move_h
#define move_h

int move_tortoise();

int move_rabbit();


#endif