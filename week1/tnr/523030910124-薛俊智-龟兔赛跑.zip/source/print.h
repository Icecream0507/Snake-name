#ifndef print_h
#define print_h

void print_position(int timer, int t, int h);


#endif