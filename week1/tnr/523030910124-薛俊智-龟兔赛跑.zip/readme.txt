****Makefile文件****
1.make
	自动编译链接当前文件夹下所有.cpp文件生成target可执行文件（main.exe）。
2.make clean
	删除所有.o二进制文件。
3.make run
	运行生成main可执行文件，如果没有则编译生成。