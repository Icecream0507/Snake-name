// 文件：print.h
#ifndef print_h
#define print_h

#include "p_r_s.h"
void prn_help();
void report(outcome);
void prn_game_status();

#endif