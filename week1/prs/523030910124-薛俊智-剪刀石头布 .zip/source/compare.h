// 文件：compare.h
#ifndef compare_h
#define compare_h

#include "p_r_s.h"

outcome compare(p_r_s, p_r_s); 

#endif