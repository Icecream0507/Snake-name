// 文件：select.h
#ifndef select_h
#define select_h

#include "p_r_s.h"
p_r_s selection_by_player();
p_r_s selection_by_machine();

#endif