// 文件：p_r_s.h
// 本文件定义了两个枚举类型
#ifndef p_r_s_h
#define p_r_s_h

enum p_r_s {rock, scissor, water, fire, paper, game, help, quit};
enum outcome {win, lose, tie, error};

#endif